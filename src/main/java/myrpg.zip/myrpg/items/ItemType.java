package myrpg.items;

public enum ItemType {
    weapon,
    armor,
    accessoire,
    quest,
    usable,
    trash
}
