package myrpg.items.gear;

public enum GearSlotType {
    lFinger,
    rFinger,
    head,
    body,
    boots,
    trinket,
    neck,
    hands,
    lHand,
    rHand,
    twoHand
}
