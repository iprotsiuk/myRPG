package myrpg.items.gear.weapon;

public enum WeaponSlots {
    lHand,
    rHand,
    oneHand,
    twoHand
}
