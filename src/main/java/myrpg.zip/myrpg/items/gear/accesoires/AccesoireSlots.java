package myrpg.items.gear.accesoires;

public enum AccesoireSlots {
    neck,
    lFinger,
    rFinger,
    trinket
}
