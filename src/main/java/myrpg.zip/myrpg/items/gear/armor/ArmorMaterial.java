package myrpg.items.gear.armor;

public enum ArmorMaterial {
    iron,
    leather,
    cloth
}
