package myrpg.items.gear.armor;

public enum ArmorSlots {
    head,
    body,
    boots
}
