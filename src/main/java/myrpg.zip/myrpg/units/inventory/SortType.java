package myrpg.units.inventory;

public enum SortType {
    name,
    itemType
}
