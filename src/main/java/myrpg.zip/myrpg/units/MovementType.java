package myrpg.units;

public enum MovementType {
    foot
}
