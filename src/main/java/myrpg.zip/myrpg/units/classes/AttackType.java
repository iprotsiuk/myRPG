package myrpg.units.classes;

public enum AttackType {
    MagicalDamage,
    meleePhysicalDamage,
    rangedPhysicalDamage
}
