package myrpg.map;

public interface IObstacle {
    ObstacleType getObstacleType();
}
