package myrpg.map;

public enum ObstacleType {
    tree,
    rock,
    pit

}
